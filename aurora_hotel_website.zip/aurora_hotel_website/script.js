const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav-links");

menuButton.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(isOpen));
  menuButton.textContent = isOpen ? "×" : "☰";
});

document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.textContent = "☰";
  });
});

const today = new Date();
const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000)
  .toISOString().split("T")[0];
const checkin = document.getElementById("checkin");
const checkout = document.getElementById("checkout");
checkin.min = localDate;
checkout.min = localDate;

checkin.addEventListener("change", () => {
  checkout.min = checkin.value;
  if (checkout.value && checkout.value <= checkin.value) checkout.value = "";
});

document.getElementById("bookingForm").addEventListener("submit", event => {
  event.preventDefault();
  const message = document.getElementById("bookingMessage");
  if (!checkin.value || !checkout.value || checkout.value <= checkin.value) {
    message.textContent = "Please choose a check-out date after your check-in date.";
    return;
  }
  message.textContent = `Thanks! Your enquiry for ${document.getElementById("guests").value.toLowerCase()} from ${checkin.value} to ${checkout.value} is ready. Please contact the hotel to confirm availability.`;
});

document.getElementById("year").textContent = new Date().getFullYear();
